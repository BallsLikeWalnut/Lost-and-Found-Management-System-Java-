package DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DAO
{
    private static String url = "jdbc:mysql://localhost:3306/LostAndFound";
    private static String username = "root";
    private static String password = "@194nobleGGN";

    public static Connection establishConnection ()
    {
        Connection con = null;
        try
        {
            con = DriverManager.getConnection(url, username, password);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return con;
    }
}
