package DBFunctions.LostItems;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

import DBConnection.DAO;
import DBFunctions.Functions;
import Items.LostItem.LostItem;

public class LostItemsTableFunctions implements Functions
{
    static Scanner scan = new Scanner (System.in);

    static Connection con = DAO.establishConnection();

    public static void addItem()
    {
        try
        {
            String query = "INSERT INTO LostItems (itemType, itemDescription, lostTime, ownerContact, deleteKey) VALUES (?, ?, ?, ?, ?)";

            PreparedStatement pstm = con.prepareStatement (query);

            LostItem lostObj = new LostItem();

            System.out.print("Enter item type: ");
            String itemType = scan.nextLine();
            lostObj.setItemType(itemType);

            System.out.print("Enter item description: ");
            String itemDescription = scan.nextLine();
            lostObj.setItemDescription(itemDescription);
            
            System.out.print("Enter item lost time: ");
            String lostTime = scan.nextLine();
            lostObj.setLostTime(lostTime);
            
            System.out.print("Enter your contact (mobile number or email): ");
            String ownerContact = scan.next();
            lostObj.setOwnerContact(ownerContact);

            System.out.print("Enter 5 character long delete key (only a person who knows the delete key of a lost item will be able to remove the record): ");
            String deleteKey = scan.next();
            lostObj.setDeleteKey(deleteKey);

            pstm.setString(1, lostObj.getItemType());
            pstm.setString(2, lostObj.getItemDescription());
            pstm.setString(3, lostObj.getLostTime());
            pstm.setString(4, lostObj.getOwnerContact());
            pstm.setString(5, lostObj.getDeleteKey());

            pstm.execute();

            System.out.println("\nItem added successfully to the list.\n");
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    public static void removeItem()
    {
        try
        {
            String query = "DELETE FROM LostItems WHERE deleteKey = ?";

            PreparedStatement pstm = con.prepareStatement (query);
            System.out.print("Enter delete key of the item: ");
            String deleteKey = scan.next();
            pstm.setString(1, deleteKey);

            int rowAffected = pstm.executeUpdate();

            if (rowAffected == 1)
            {
                System.out.println("\nItem removed successfully from the list.\n");   
            }
            else
            {
                System.out.println("\nInvalid delete key\n");
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    public static void showTable()
    {
        try
        {
            String query = "SELECT ID, itemType, itemDescription, lostTime, ownerContact FROM LostItems";

            Statement stm = con.createStatement();

            ResultSet result = stm.executeQuery(query);

            while ( result.next() )
            {
                System.out.print ("ID: " + result.getInt (1) + ", " );
                System.out.print ("itemType: " + result.getString (2) + ", "  );
                System.out.print ("itemDescription: " + result.getString (3) + ", "  );
                System.out.print ("lostTime: " + result.getString (4) + ", "   );
                System.out.print ("ownerContact: " + result.getString (5) );
                System.out.println();
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    public static void writeToFile()
    {
        try
        {
            String query = "SELECT ID, itemType, itemDescription, lostTime, ownerContact FROM LostItems";

            Statement stm = con.createStatement();

            ResultSet result = stm.executeQuery(query);

            try (FileWriter writer = new FileWriter("lost_items_data.txt"))
            {
                while (result.next())
                {
                    int id = result.getInt(1);
                    String itemType = result.getString(2);
                    String itemDescription = result.getString(3);
                    String lostTime = result.getString(4);
                    String ownerContact = result.getString(5);

                    String itemData = "ID: " + id + ", itemType: " + itemType + ", itemDescription: " + itemDescription + ", lostTime: " + lostTime + ", ownerContact: " + ownerContact;

                    writer.write(itemData);
                    writer.write(System.lineSeparator());
                }

                System.out.println("Data exported.");
            }
            
            catch (IOException e)
            {
                e.printStackTrace();
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    public static void closeResources()
    {
        scan.close();
        try
        {
            con.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}
