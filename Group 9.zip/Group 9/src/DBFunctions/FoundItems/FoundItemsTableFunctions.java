package DBFunctions.FoundItems;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import DBConnection.DAO;
import DBFunctions.Functions;
import Items.FoundItem.FoundItem;

public class FoundItemsTableFunctions implements Functions
{
    static Scanner scan = new Scanner (System.in);

    static Connection con = DAO.establishConnection();

    public static void addItem()
    {
        try
        {
            String query = "INSERT INTO FoundItems (itemType, itemDescription, foundTime, founderContact, deleteKey) VALUES (?, ?, ?, ?, ?)";

            PreparedStatement pstm = con.prepareStatement (query);

            FoundItem foundObj = new FoundItem();

            System.out.print("Enter item type: ");
            String itemType = scan.nextLine();
            foundObj.setItemType(itemType);

            System.out.print("Enter item description: ");
            String itemDescription = scan.nextLine();
            foundObj.setItemDescription(itemDescription);
            
            System.out.print("Enter item found time: ");
            String foundTime = scan.nextLine();
            foundObj.setFoundTime(foundTime);
            
            System.out.print("Enter your contact (mobile number or email): ");
            String founderContact = scan.next();
            foundObj.setFounderContact(founderContact);

            System.out.print("Enter 5 character long delete key (only a person who knows the delete key of a lost item will be able to remove the record): ");
            String deleteKey = scan.next();
            foundObj.setDeleteKey(deleteKey);

            pstm.setString(1, foundObj.getItemType());
            pstm.setString(2, foundObj.getItemDescription());
            pstm.setString(3, foundObj.getFoundTime());
            pstm.setString(4, foundObj.getFounderContact());
            pstm.setString(5, foundObj.getDeleteKey());

            pstm.execute();

            System.out.println("\nItem added successfully to the list.\n");
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    public static void removeItem()
    {
        try
        {
            String query = "DELETE FROM FoundItems WHERE deleteKey = ?";

            PreparedStatement pstm = con.prepareStatement (query);
            System.out.print("Enter delete key of the item: ");
            String deleteKey = scan.next();
            pstm.setString(1, deleteKey);

            int rowAffected = pstm.executeUpdate();

            if (rowAffected == 1)
            {
                System.out.println("\nItem removed successfully from the list.\n");   
            }
            else
            {
                System.out.println("\nInvalid delete key\n");
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    public static void showTable()
    {
        try
        {
            String query = "SELECT ID, itemType, itemDescription, foundTime, founderContact FROM FoundItems";

            Statement stm = con.createStatement();

            ResultSet result = stm.executeQuery(query);

            while ( result.next() )
            {
                System.out.print ("ID: " + result.getInt (1) + ", " );
                System.out.print ("itemType: " + result.getString (2) + ", "  );
                System.out.print ("itemDescription: " + result.getString (3) + ", "  );
                System.out.print ("foundTime: " + result.getString (4) + ", "   );
                System.out.print ("founderContact: " + result.getString (5) );
                System.out.println();
            }

        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

    }

    public static void writeToFile()
    {
        try
        {
            String query = "SELECT ID, itemType, itemDescription, foundTime, founderContact FROM FoundItems";

            Statement stm = con.createStatement();

            ResultSet result = stm.executeQuery(query);

            try (FileWriter writer = new FileWriter("found_items_data.txt"))
            {
                while (result.next())
                {
                    int id = result.getInt(1);
                    String itemType = result.getString(2);
                    String itemDescription = result.getString(3);
                    String foundTime = result.getString(4);
                    String founderContact = result.getString(5);

                    String itemData = "ID: " + id + ", itemType: " + itemType + ", itemDescription: " + itemDescription + ", foundTime: " + foundTime + ", founderContact: " + founderContact;

                    writer.write(itemData);
                    writer.write(System.lineSeparator());
                }

                System.out.println("Data exported.");
            }
            
            catch (IOException e)
            {
                e.printStackTrace();
            }

            con.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    public static void closeResources()
    {
        scan.close();
        try
        {
            con.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}
