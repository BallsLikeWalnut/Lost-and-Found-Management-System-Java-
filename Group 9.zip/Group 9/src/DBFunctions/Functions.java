package DBFunctions;

import java.sql.Connection;
import java.sql.SQLException;

import java.util.Scanner;

import DBConnection.DAO;

public interface Functions
{
    static Scanner scan = new Scanner (System.in);

    static Connection con = DAO.establishConnection();

    public static void addItem()
    {

    }

    public static void removeItem()
    {
        
    }

    public static void showTable()
    {

    }

    public static void closeResources()
    {
        scan.close();
        try
        {
            con.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

}
