import DBFunctions.FoundItems.FoundItemsTableFunctions;
import DBFunctions.LostItems.LostItemsTableFunctions;

import java.util.Scanner;

public class App
{
    public static void validArgs ()
    {
        System.out.println("Error: Enter one command line argument");
    }

    public static void validArgs (int a)
    {
        System.out.println("Enter valid command line argument:");
        System.out.println("\t 1) Lost - for lost item service");
        System.out.println("\t 2) Found - for found item service");
    }

    public static void main(String[] args)
    {
        if (args.length != 1)
        {
            validArgs();
            return;
        }

        Scanner scan = new Scanner (System.in);

        int choice;

        if (args[0].equals("Lost"))
        {
            
            System.out.println("--------------Lost & Found Management System--------------\n\n\n");

            System.out.println("Lost Items Service");
            while (true)
            {
                System.out.println("Enter the corresponding number for desired action.\n");

                System.out.println("1) Show list of lost items");
                System.out.println("2) Add a lost item to list");
                System.out.println("3) Remove a lost item from list");
                System.out.println("4) Write data to file");
                System.out.println("5) Exit program");
                System.out.println();

                System.out.print("Your choice: ");
                choice = scan.nextInt();

                switch (choice)
                {
                    case 1:
                        LostItemsTableFunctions.showTable();
                        
                        break;

                    case 2:
                        LostItemsTableFunctions.addItem();                    
                        
                        break;
                        
                    case 3:
                        LostItemsTableFunctions.removeItem();
                        
                        break;

                    case 4:
                        LostItemsTableFunctions.writeToFile();

                        break;

                    case 5:
                        scan.close();
                        LostItemsTableFunctions.closeResources();
                        return;
                    
                    default:
                        System.out.println("Invalid");
                        break;
                }
            }
        }

        else if (args[0].equals("Found"))
        {
            
            System.out.println("--------------Lost & Found Management System--------------\n\n\n");

            System.out.println("Found Items Service");
            while (true)
            {
                System.out.println("Enter the corresponding number for desired action.\n");

                System.out.println("1) Show list of found items");
                System.out.println("2) Add a found item to list");
                System.out.println("3) Remove a found item from the list");
                System.out.println("4) Write data to file");
                System.out.println("5) Exit program");
                System.out.println();

                System.out.print("Your choice: ");
                choice = scan.nextInt();

                switch (choice)
                {
                    case 1:
                        FoundItemsTableFunctions.showTable();
                        
                        break;

                    case 2:
                        FoundItemsTableFunctions.addItem();                    
                        
                        break;
                        
                    case 3:
                        FoundItemsTableFunctions.removeItem();
                        
                        break;

                    case 4:
                        FoundItemsTableFunctions.writeToFile();

                        break;

                    case 5:
                        scan.close();
                        FoundItemsTableFunctions.closeResources();
                        return;
                    
                    default:
                        System.out.println("Invalid");
                        break;
                }
            }
        }

        else
        {
            validArgs(1);
            scan.close();
        }
    }
}