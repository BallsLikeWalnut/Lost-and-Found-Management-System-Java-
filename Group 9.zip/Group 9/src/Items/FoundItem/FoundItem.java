package Items.FoundItem;

import Items.Items;

public class FoundItem extends Items
{
    String foundTime;
    String founderContact;
    
    public void setFoundTime(String foundTime)
    {
        this.foundTime = foundTime;
    }

    public void setFounderContact(String founderContact)
    {
        this.founderContact = founderContact;
    }

    public String getFoundTime()
    {
        return this.foundTime;
    }

    public String getFounderContact()
    {
        return this.founderContact;
    }
}
