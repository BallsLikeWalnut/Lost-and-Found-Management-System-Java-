package Items.LostItem;

import Items.Items;

public class LostItem extends Items
{
    String lostTime;
    String ownerContact;
    
    public void setLostTime(String lostTime)
    {
        this.lostTime = lostTime;
    }

    public void setOwnerContact(String ownerContact)
    {
        this.ownerContact = ownerContact;
    }

    public String getLostTime()
    {
        return this.lostTime;
    }

    public String getOwnerContact()
    {
        return this.ownerContact;
    }
}
