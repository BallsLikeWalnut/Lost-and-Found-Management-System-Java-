package Items;

public abstract class Items
{
    String itemType;
    String itemDescription;
    String deleteKey;
    
    public void setItemType(String itemType)
    {
        this.itemType = itemType;
    }

    public void setItemDescription(String itemDescription)
    {
        this.itemDescription = itemDescription;
    }

    public void setDeleteKey(String deleteKey)
    {
        this.deleteKey = deleteKey;
    }

    public String getItemType()
    {
        return this.itemType;
    }

    public String getItemDescription()
    {
        return this.itemDescription;
    }

    public String getDeleteKey()
    {
        return this.deleteKey;
    }
}
